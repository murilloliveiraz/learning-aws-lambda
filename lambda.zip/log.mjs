export function log(msg) {
    console.log('Adicioanndo log via funcao:', msg)
}